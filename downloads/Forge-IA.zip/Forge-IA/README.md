# Forge IA Games

Aplicativo separado do Kaito Nami. Cria e edita jogos HTML5 com a OpenAI, permite importar HTML, editar o código, jogar uma prévia isolada e baixar um HTML independente. Inclui uma demonstração pré-criada; ela não depende da IA.

## Abrir no computador

1. Instale Python 3.11 ou superior.
2. Nesta pasta, execute `python -m pip install -r requirements.txt`.
3. Copie `.env.example` para `.env`. Preencha `OPENAI_API_KEY` somente nesse arquivo do servidor. Nunca envie a chave pelo chat nem coloque no JavaScript.
4. Execute `python app.py`.
5. Abra **http://localhost:8000** no mesmo computador.

Sem chave, a demonstração, a importação, o editor e o download continuam funcionando. A geração e edição por IA requerem uma chave válida, acesso à API e créditos. O modelo padrão é `gpt-4.1`; configure `OPENAI_MODEL` conforme a disponibilidade da sua conta.

## Hospedagem

O endereço localhost só funciona no computador que executa o servidor. Um link público com geração exige hospedar este aplicativo Python com HTTPS, configurar a chave nas variáveis privadas e liberar acesso de saída a `api.openai.com`. Defina também `FORGE_ACCESS_TOKEN` para restringir o uso da geração paga; a interface pedirá essa senha de acesso, que não é a chave da OpenAI. Use `HOST=0.0.0.0` e o `PORT` fornecido pela hospedagem. Este projeto não provisiona hospedagem nem publica segredos.

A prévia usa iframe sandbox sem origem compartilhada e CSP para bloquear recursos externos. O HTML baixado é o documento original. O gerador valida o formato, mas jogos novos ainda precisam de testes de jogabilidade; não garante automaticamente que toda saída da IA não tenha bugs. O aplicativo não salva o histórico no servidor; baixe seu jogo antes de fechar a página.

## Testar

`python -m unittest discover -s tests -v`
