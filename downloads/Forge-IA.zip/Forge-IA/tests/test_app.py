import json
import os
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from fastapi.testclient import TestClient
import app as module

GAME={'title':'Teste','description':'Jogo original','html':'<!DOCTYPE html><html><body>Jogo</body></html>','controls':['Setas'],'features':['Pontos']}
class ForgeTests(unittest.TestCase):
    def setUp(self):
        self.env=patch.dict(os.environ,{'OPENAI_API_KEY':'','FORGE_ACCESS_TOKEN':''})
        self.env.start()
        self.client=TestClient(module.app)
    def tearDown(self): self.env.stop()
    def test_editor_without_key(self):
        self.assertEqual(self.client.get('/').status_code,200)
        self.assertFalse(self.client.get('/api/status').json()['configured'])
        response=self.client.post('/api/generate',json={'prompt':'Um jogo de surfe'})
        self.assertEqual(response.status_code,503)
        self.assertIn('OPENAI_API_KEY',response.json()['detail'])
    def test_validation(self):
        self.assertEqual(self.client.post('/api/generate',json={'prompt':'a'}).status_code,422)
    def test_access_token_and_origin(self):
        os.environ['FORGE_ACCESS_TOKEN']='studio-test'
        self.assertEqual(self.client.post('/api/generate',json={'prompt':'Um jogo'}).status_code,401)
        self.assertNotIn('studio-test',self.client.get('/api/status').text)
        response=self.client.post('/api/generate',json={'prompt':'Um jogo'},headers={'Authorization':'Bearer studio-test','Origin':'https://outro.example'})
        self.assertEqual(response.status_code,403)
    def fake_client(self,payload):
        client=SimpleNamespace(responses=SimpleNamespace(create=AsyncMock(return_value=SimpleNamespace(status='completed',output_text=json.dumps(payload)))))
        context=AsyncMock();context.__aenter__.return_value=client
        return context,client
    def test_create_and_edit_preserve_document_context(self):
        os.environ['OPENAI_API_KEY']='server-test-key'
        for mode in ['create','edit']:
            context,client=self.fake_client(GAME)
            with patch.object(module,'AsyncOpenAI',return_value=context):
                r=self.client.post('/api/generate',json={'prompt':'Adicione cristais','mode':mode,'current_html':GAME['html'],'history':['Crie surfe']})
            self.assertEqual(r.status_code,200,r.text)
            self.assertEqual(r.json(),GAME)
            kwargs=client.responses.create.call_args.kwargs
            sent=json.loads(kwargs['input'])
            self.assertEqual(sent['html_anterior'],GAME['html'] if mode=='edit' else '')
            self.assertNotIn('server-test-key',r.text)
            self.assertTrue(kwargs['text']['format']['strict'])
    def test_incomplete_html_is_rejected(self):
        os.environ['OPENAI_API_KEY']='server-test-key'
        context,_=self.fake_client({**GAME,'html':'<html><body>Um documento incompleto</body></html>'})
        with patch.object(module,'AsyncOpenAI',return_value=context):
            self.assertEqual(self.client.post('/api/generate',json={'prompt':'Crie surfe'}).status_code,502)
    def test_edit_requires_game(self):
        os.environ['OPENAI_API_KEY']='server-test-key'
        with patch.object(module,'AsyncOpenAI',object()):
            self.assertEqual(self.client.post('/api/generate',json={'prompt':'Mude a cor','mode':'edit'}).status_code,422)
if __name__=='__main__': unittest.main()
