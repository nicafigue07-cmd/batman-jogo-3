"""Forge IA: execute python app.py. A chave OpenAI permanece no servidor."""
import asyncio
import json
import os
from pathlib import Path
from typing import Literal

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, ValidationError
try:
    from openai import AsyncOpenAI, OpenAIError, APITimeoutError
except ImportError:
    AsyncOpenAI = None
    class OpenAIError(Exception): pass
    class APITimeoutError(OpenAIError): pass

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / '.env')
MODEL = os.getenv('OPENAI_MODEL', 'gpt-4.1')
app = FastAPI(title='Forge IA Games', version='1.0.0')
app.mount('/static', StaticFiles(directory=BASE_DIR / 'static'), name='static')
slots = asyncio.Semaphore(2)

SYSTEM_PROMPT = '''Você é FORGE IA, um estúdio de jogos de navegador. Crie ou edite um jogo real e inteiro, compacto e divertido. Entregue um único HTML completo com CSS e JS inline, em português do Brasil. Sem bibliotecas externas, CDN, importações, APIs, chamadas de rede ou recursos remotos. Prefira Canvas 2D e arte procedural original. Inclua objetivo, desafio, progressão, vitória/derrota, reinício, controles de teclado e toque, HUD e menus. Adapte a tela e devicePixelRatio. O jogo roda em iframe sandbox sem acesso a cookies ou armazenamento: se usar armazenamento, proteja com try/catch. Limite partículas e deltaTime, não duplique listeners nem loops. Use apenas recursos originais. Se receber HTML anterior, preserve as mecânicas funcionais e aplique a alteração, devolvendo todo o documento. Não faça perguntas. Não entregue placeholders nem finja implementar jogos AAA. Revise inicialização, controles, colisões, pontuação e reinício. Responda apenas JSON conforme o schema. html começa com <!DOCTYPE html> e termina com </html>.'''
GAME_SCHEMA = {'type':'object','properties':{'title':{'type':'string'},'description':{'type':'string'},'html':{'type':'string'},'controls':{'type':'array','items':{'type':'string'}},'features':{'type':'array','items':{'type':'string'}}},'required':['title','description','html','controls','features'],'additionalProperties':False}

class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=3500)
    mode: Literal['create','edit'] = 'create'
    current_html: str = Field(default='', max_length=300_000)
    history: list[str] = Field(default_factory=list, max_length=10)

class GenerateResponse(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    description: str = Field(max_length=5000)
    html: str = Field(min_length=30, max_length=300_000)
    controls: list[str] = Field(max_length=30)
    features: list[str] = Field(max_length=30)

def has_api_key():
    value = os.getenv('OPENAI_API_KEY','').strip()
    return bool(value) and value != 'coloque_sua_chave_aqui'

@app.get('/')
def index():
    return FileResponse(BASE_DIR / 'static/index.html')

@app.get('/api/status')
def status():
    return {'configured': has_api_key() and AsyncOpenAI is not None, 'model': MODEL, 'protected': bool(os.getenv('FORGE_ACCESS_TOKEN'))}

@app.post('/api/generate', response_model=GenerateResponse)
async def generate(body: GenerateRequest, request: Request):
    token = os.getenv('FORGE_ACCESS_TOKEN')
    if token:
        import secrets
        supplied = request.headers.get('authorization','')
        if not secrets.compare_digest(supplied, 'Bearer ' + token):
            raise HTTPException(401, 'Informe a senha do estúdio para gerar jogos.')
    origin = request.headers.get('origin')
    if origin and origin.rstrip('/') != str(request.base_url).rstrip('/'):
        raise HTTPException(403, 'Abra o Forge no endereço do próprio servidor.')
    if not has_api_key():
        raise HTTPException(503, 'A geração por IA ainda não foi configurada. Defina OPENAI_API_KEY no arquivo .env do servidor. A demonstração e o editor já funcionam.')
    if AsyncOpenAI is None:
        raise HTTPException(503, 'Instale as dependências do servidor com pip install -r requirements.txt.')
    if not body.prompt.strip():
        raise HTTPException(422, 'Descreva o jogo que deseja criar.')
    if body.mode == 'edit' and not body.current_html.strip():
        raise HTTPException(422, 'Abra ou crie um jogo antes de pedir uma edição.')
    if any(len(item)>3500 for item in body.history):
        raise HTTPException(422, 'O histórico contém um pedido muito longo.')
    if slots.locked():
        raise HTTPException(429, 'O estúdio está ocupado. Aguarde a geração atual e tente novamente.')
    content = json.dumps({'pedido':body.prompt,'modo':body.mode,'historico':body.history,'html_anterior':body.current_html if body.mode=='edit' else ''},ensure_ascii=False)
    try:
        async with slots:
            async with AsyncOpenAI(timeout=150, max_retries=1) as client:
                result = await client.responses.create(model=MODEL, instructions=SYSTEM_PROMPT, input=content, max_output_tokens=16000, text={'format':{'type':'json_schema','name':'game','strict':True,'schema':GAME_SCHEMA}})
        if result.status != 'completed':
            raise HTTPException(502, 'A resposta ficou incompleta. Tente um jogo mais compacto.')
        game = GenerateResponse.model_validate_json(result.output_text)
        if not game.html.lstrip().lower().startswith('<!doctype html>') or not game.html.rstrip().lower().endswith('</html>'):
            raise HTTPException(502, 'A IA não devolveu um HTML completo. Tente novamente.')
        return game
    except APITimeoutError:
        raise HTTPException(504, 'A geração demorou demais. Tente novamente com um pedido menor.') from None
    except OpenAIError:
        raise HTTPException(502, 'Não foi possível gerar o jogo. Verifique a chave, o saldo e o modelo no servidor.') from None
    except (ValidationError, ValueError, TypeError):
        raise HTTPException(502, 'A resposta da IA não pôde ser lida. Tente novamente.') from None

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host=os.getenv('HOST','127.0.0.1'), port=int(os.getenv('PORT','8000')))
