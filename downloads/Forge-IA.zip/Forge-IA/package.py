"""Cria uma cópia portátil do editor e um ZIP do aplicativo Python, sem segredos."""
import json
import zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
out=Path('/workspace/para-jogar');out.mkdir(exist_ok=True)
html=(root/'static/index.html').read_text()
html=html.replace('<link rel="stylesheet" href="/static/style.css">','<style>'+(root/'static/style.css').read_text()+'</style>')
demo=json.dumps((root/'static/demo.html').read_text(),ensure_ascii=False).replace('</','<\\/')
html=html.replace('<script src="/static/app.js" defer></script>','<script>window.FORGE_DEMO='+demo+';</script><script>'+(root/'static/app.js').read_text()+'</script>')
(root/'Forge-IA.html').write_text(html)
(out/'Forge-IA.html').write_text(html)
with zipfile.ZipFile(out/'Forge-IA.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in ['app.py','requirements.txt','.env.example','.gitignore','README.md','Forge-IA.html','package.py','static/index.html','static/style.css','static/app.js','static/demo.html','tests/test_app.py']:
        z.write(root/name,'Forge-IA/'+name)
    assert z.testzip() is None
print('Editor portátil e aplicativo completo preparados em',out)
