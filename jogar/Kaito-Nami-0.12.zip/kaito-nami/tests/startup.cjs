const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
function environment({href='https://example.test/kaito/?v=0.6',stored={},storageError=false}={}){
 const elements=new Map(),storage=new Map(Object.entries(stored)),session=new Map(),listeners={},canvasEvents={},contexts=[],timers=[];
 const el=id=>{if(!elements.has(id))elements.set(id,{classList:{add(){},remove(){}},textContent:''});return elements.get(id);};
 const context={URL,performance:{now:()=>0},console:{error(){},warn(){}},document:{getElementById:el},addEventListener:(name,fn)=>listeners[name]=fn,
   localStorage:{getItem:key=>{if(storageError)throw Error('blocked');return storage.get(key)??null;},setItem:(key,value)=>{if(storageError)throw Error('blocked');storage.set(key,value);}},
   sessionStorage:{getItem:key=>session.get(key)??null,setItem:(key,v)=>session.set(key,v),removeItem:key=>session.delete(key)},
   location:{href,reloads:0,reload(){this.reloads++;},replace(url){this.replaced=url;}},setTimeout:fn=>{timers.push(fn);return timers.length;},clearTimeout(){},navigator:{clipboard:{writeText:async value=>context.copied=value}}};
 context.window=context;vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/runtime.js'),'utf8'),context);
 const canvas={addEventListener:(name,fn)=>canvasEvents[name]=fn,getContext:(name,options)=>{contexts.push({name,options});return {getContextAttributes:()=>options,getParameter:()=> 'test-driver'};}};
 return {context,boot:context.KaitoBoot,el,storage,session,listeners,canvasEvents,contexts,timers,canvas};
}
test('light mode requests a genuinely different context and does not erase progress',()=>{
 const e=environment({href:'https://example.test/kaito/?mode=light',stored:{'kaito-nami-v2':'{"mission":12}'}});e.boot.context(e.canvas);assert.equal(e.contexts[0].options.antialias,false);assert.equal(e.contexts[0].options.powerPreference,'low-power');e.boot.restart(true);assert.equal(e.storage.get('kaito-nami-v2'),'{"mission":12}');assert.equal(JSON.parse(e.storage.get('kaito-options')).fpsCap,30);assert(e.context.location.replaced.includes('mode=light'));
});
test('normal context keeps antialias and reports actual creation errors',()=>{
 const e=environment();e.boot.context(e.canvas);assert.equal(e.contexts[0].options.antialias,true);e.canvas.getContext=()=>{throw Error('driver unavailable');};e.boot.context(e.canvas);assert.equal(e.boot.lastError.code,'CONTEXT_CREATION');assert.equal(e.boot.lastError.stage,'context');assert.equal(e.el('fatalText').textContent,'driver unavailable');
});
test('unavailable WebGL produces a classified, copyable local diagnostic',async()=>{
 const e=environment();e.canvas.getContext=()=>null;assert.equal(e.boot.context(e.canvas),null);assert.equal(e.boot.lastError.code,'WEBGL_UNAVAILABLE');await e.el('copyError').onclick();assert.equal(JSON.parse(e.context.copied).code,'WEBGL_UNAVAILABLE');assert(e.storage.has('kaito-last-error'));
});
test('context loss calls save, stops rendering and restores at most once per session',()=>{
 const e=environment();let saved=0,prevented=false;e.boot.bindCanvas(e.canvas,()=>saved++);e.canvasEvents.webglcontextlost({preventDefault(){prevented=true;}});assert(prevented);assert.equal(saved,1);assert(e.boot.contextLost&&e.boot.failed);assert.equal(e.boot.lastError.code,'CONTEXT_LOST');e.canvasEvents.webglcontextrestored();assert.equal(e.context.location.reloads,1);e.canvasEvents.webglcontextrestored();assert.equal(e.context.location.reloads,1);
});
test('watchdog distinguishes an unfinished boot from an already rendered game',()=>{
 const e=environment();e.timers[0]();assert.equal(e.boot.lastError.code,'BOOT_TIMEOUT');const good=environment();good.boot.complete();good.timers[0]();assert(!good.boot.failed);assert.equal(JSON.parse(good.storage.get('kaito-last-boot')).code,'READY');
});
test('safe mode still works when storage is blocked because it is encoded in the link',()=>{
 const e=environment({storageError:true});e.boot.restart(true);const next=environment({href:e.context.location.replaced,storageError:true});assert(next.boot.compatibility);next.boot.context(next.canvas);assert.equal(next.contexts[0].options.antialias,false);
});
test('compatibility mode skips instancing rather than compiling the same GPU path again',()=>{
 const e=environment({stored:{'kaito-options':'{"compatibility":true}'}});vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/renderer.js'),'utf8'),e.context);const renderer=new e.context.KaitoBatch({getExtension(){throw Error('must not request extension');}},'','',{});assert.equal(renderer.enabled,false);assert.equal(renderer.reason,'Modo de compatibilidade');
});
test('loading counts only completed unique milestones and stops after a module failure',()=>{
 const e=environment();assert.equal(e.el('loadingProgress').value,1);e.boot.mark('geometry');assert.equal(e.el('loadingProgress').value,1);e.boot.finish('geometry');e.boot.finish('geometry');assert.equal(e.el('loadingProgress').value,2);
 let nextRan=false;e.boot.enqueue('systems',()=>{throw Error('injected module failure');});e.boot.enqueue('core',()=>nextRan=true);e.timers[1]();assert.equal(e.boot.lastError.code,'MODULE_INITIALIZATION');assert.equal(e.boot.lastError.stage,'systems');assert.equal(nextRan,false);assert.equal(e.el('loadingProgress').value,2);e.boot.complete();assert(!e.boot.ready);
});
test('queued modules run in order on separate tasks and report their completed work',()=>{
 const e=environment(),order=[];e.boot.enqueue('renderer',()=>order.push('renderer'));e.boot.enqueue('systems',()=>order.push('systems'));assert.deepEqual(order,[]);e.timers[1]();assert.deepEqual(order,['renderer']);assert.equal(e.el('loadingProgress').value,2);e.timers[2]();assert.deepEqual(order,['renderer','systems']);assert.equal(e.el('loadingProgress').value,3);
});
test('a driver refusing the normal context is retried without antialias before giving up',()=>{
 const e=environment();e.canvas.getContext=(name,options)=>{e.contexts.push({name,options});return options.antialias?null:{getContextAttributes:()=>options};};const gl=e.boot.context(e.canvas);assert(gl);assert(e.boot.compatibility);assert(!e.boot.failed);assert.equal(e.contexts.length,3);assert.equal(e.boot.graphics.antialias,false);assert(e.boot.history.some(x=>x.code==='CONTEXT_RETRY'));
});
test('a background tab defers its watchdog and a denied clipboard opens the manual diagnostic',async()=>{
 const e=environment();e.context.document.hidden=true;e.timers[0]();assert(!e.boot.failed);e.context.document.hidden=false;e.timers[1]();assert.equal(e.boot.lastError.code,'BOOT_TIMEOUT');e.context.navigator.clipboard.writeText=async()=>{throw Error('denied');};await e.el('copyError').onclick();assert.equal(e.el('diagnosticPanel').open,true);assert(e.el('errorSummary').textContent.includes('BOOT_TIMEOUT'));
});

test('startup diagnostic measures completed milestones and the first ready frame',()=>{
 const e=environment();e.context.performance.now=()=>42;e.boot.mark('geometry');assert.equal(e.boot.history.at(-1).ms,42);e.context.performance.now=()=>75;e.boot.complete();const d=e.boot.diagnostic();assert.equal(d.timing.readyMs,75);assert.equal(d.timing.elapsedMs,75);
});
